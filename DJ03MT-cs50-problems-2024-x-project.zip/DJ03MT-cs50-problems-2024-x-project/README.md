# Pagina-Web_Aerolinea
NOMBRE DEL PROYECTO: NicaAirFly
LINK DEL VIDEO: https://youtu.be/nG54W-et3M0
Description:
Esto software web, es una estructura de lo que pudiese ser una Aeroline.!
Lo que puede hacer con ella es registrar personal, registrar vuelos así como tambien mandarlos a una tabla para saber que vuelos estan disponibles.
Sera un software en constante desarollo, por lo tanto aun no esta terminador.!


Templantes Utilizados.
°DIVI
°Boostrap


